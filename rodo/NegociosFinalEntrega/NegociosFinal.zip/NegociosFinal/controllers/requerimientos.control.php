<?php

  require_once("libs/template_engine.php");
  function run(){
    renderizar("requerimientos",array()); 
  }
  run();
?>