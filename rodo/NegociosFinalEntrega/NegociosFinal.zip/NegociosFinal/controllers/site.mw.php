<?php
//middleware de configuración de todo el sitio

function site_init(){
    addToContext("page_title","MUFLO DESIGN");
}
    
site_init();
?>