<?php

  require_once("libs/template_engine.php");
  function run(){
    renderizar("nosotros",array()); 
  }
  run();
?>